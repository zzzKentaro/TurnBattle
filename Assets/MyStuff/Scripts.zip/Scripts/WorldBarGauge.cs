using UnityEngine;

/// <summary>
/// ���[���h��Ԃɔz�u�����o�[�Q�[�WUI�R���|�[�l���g�B
/// </summary>
public class WorldBarGauge : MonoBehaviour
{
    [Header("Fill Object")]
    [SerializeField] private Transform fillTransform;

    [Header("Animation")]
    [SerializeField] private bool smoothAnimation = true;
    [SerializeField] private float animationSpeed = 10f;

    private Vector3 initialScale;
    private Vector3 initialPosition;
    private float currentRatio = 1f;
    private float targetRatio = 1f;

    private void Awake()
    {
        if (fillTransform == null)
        {
            Debug.LogError($"{name}: fillTransform �����ݒ�ł��B");
            enabled = false;
            return;
        }

        initialScale = fillTransform.localScale;
        initialPosition = fillTransform.localPosition;
        if (Mathf.Approximately(initialScale.x, 0f))
        {
            initialScale.x = 1f;
        }
    }

    private void Update()
    {
        if (smoothAnimation)
        {
            currentRatio = Mathf.Lerp(currentRatio, targetRatio, 1f - Mathf.Exp(-animationSpeed * Time.deltaTime));
        }
        else
        {
            currentRatio = targetRatio;
        }

        ApplyRatio(currentRatio);
    }

    public void SetRatio(float ratio)
    {
        targetRatio = Mathf.Clamp01(ratio);
    }

    public void SetImmediate(float ratio)
    {
        targetRatio = Mathf.Clamp01(ratio);
        currentRatio = targetRatio;
        ApplyRatio(currentRatio);
    }

    private void ApplyRatio(float ratio)
    {
        Vector3 scale = initialScale;
        scale.x *= Mathf.Max(0f, ratio);
        fillTransform.localScale = scale;
        fillTransform.localPosition = initialPosition;
    }
}
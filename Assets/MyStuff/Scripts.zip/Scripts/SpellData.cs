using UnityEngine;

namespace TurnBasedBattle
{
    [CreateAssetMenu(fileName = "SpellData", menuName = "TurnBattle/Spell Data")]
    public class SpellData : ScriptableObject
    {
        [Header("���ʏ��")]
        [SerializeField] private string spellId = "spell_new";
        [SerializeField] private string displayName = "New Spell";
        [SerializeField, TextArea] private string description;
        [SerializeField] private Sprite iconSprite;
        [SerializeField] private OneShotParticleCallback impactEffectPrefab;
        [SerializeField] private AudioClip attackEffectSe;

        [Header("��{�ݒ�")]
        [SerializeField] private ElementType element = ElementType.None;
        [SerializeField] private SpellCategory category = SpellCategory.Attack;
        [SerializeField] private TargetType targetType = TargetType.SingleEnemy;
        [SerializeField, Min(0)] private int mpCost = 0;

        [Header("�U�� / ��")]
        [SerializeField] private float attackCoefficient = 1.0f;
        [SerializeField] private float defenseCoefficient = 1.0f;
        [SerializeField, Min(1)] private int hitCount = 1;
        [SerializeField, Min(0)] private int flatHealAmount = 0;
        [SerializeField, Min(0)] private int stackPerHit = 1;
        [SerializeField] private bool useCurrentHpAsAttackSource = false;
        [SerializeField, Range(0f, 3f)] private float missingHpAttackCoefficientBonusAtZeroHp = 0f;
        [SerializeField] private bool allowCritical = true;
        [SerializeField, Min(0f)] private float defensePenetration = 0f;

        [Header("�s�����␳")]
        [SerializeField] private OrderAffinity orderAffinity = OrderAffinity.Any;
        [SerializeField] private float firstOrderAttackCoefficientBonus = 0f;
        [SerializeField] private float secondOrderAttackCoefficientBonus = 0f;
        [SerializeField] private float thirdOrderAttackCoefficientBonus = 0f;
        [SerializeField] private float nextSpellAttackCoefficientBonus = 0f;

        [Header("�\�͒l�o�t / �f�o�t")]
        [SerializeField] private int selfAttackStatDelta = 0;
        [SerializeField] private int selfDefenseStatDelta = 0;
        [SerializeField] private int targetAttackStatDelta = 0;
        [SerializeField] private int targetDefenseStatDelta = 0;
        [SerializeField, Min(0)] private int statModifierDurationTurns = 0;

        [Header("�W���o�t / �f�o�t")]
        [SerializeField] private float selfAttackCoefficientDelta = 0f;
        [SerializeField] private float selfDefenseCoefficientDelta = 0f;
        [SerializeField] private float targetAttackCoefficientDelta = 0f;
        [SerializeField] private float targetDefenseCoefficientDelta = 0f;
        [SerializeField, Min(0)] private int coefficientModifierDurationTurns = 0;

        [Header("���x������")]
        [SerializeField, Range(0f, 1f)] private float levelAttackCoefficientPerLevel = 0.05f;
        [SerializeField] private int maxLevel = 6;

        public string SpellId => spellId;
        public string DisplayName => displayName;
        public string Description => description;
        public Sprite IconSprite => iconSprite;
        public OneShotParticleCallback ImpactEffectPrefab => impactEffectPrefab;
        public AudioClip AttackEffectSe => attackEffectSe;
        public ElementType Element => element;
        public SpellCategory Category => category;
        public TargetType TargetType => targetType;
        public int MpCost => mpCost;
        public float AttackCoefficient => attackCoefficient;
        public float DefenseCoefficient => defenseCoefficient;
        public int HitCount => hitCount;
        public int FlatHealAmount => flatHealAmount;
        public int StackPerHit => stackPerHit;
        public bool UseCurrentHpAsAttackSource => useCurrentHpAsAttackSource;
        public float MissingHpAttackCoefficientBonusAtZeroHp => missingHpAttackCoefficientBonusAtZeroHp;
        public bool AllowCritical => allowCritical;
        public float DefensePenetration => defensePenetration;
        public OrderAffinity OrderAffinity => orderAffinity;
        public float NextSpellAttackCoefficientBonus => nextSpellAttackCoefficientBonus;
        public int SelfAttackStatDelta => selfAttackStatDelta;
        public int SelfDefenseStatDelta => selfDefenseStatDelta;
        public int TargetAttackStatDelta => targetAttackStatDelta;
        public int TargetDefenseStatDelta => targetDefenseStatDelta;
        public int StatModifierDurationTurns => statModifierDurationTurns;
        public float SelfAttackCoefficientDelta => selfAttackCoefficientDelta;
        public float SelfDefenseCoefficientDelta => selfDefenseCoefficientDelta;
        public float TargetAttackCoefficientDelta => targetAttackCoefficientDelta;
        public float TargetDefenseCoefficientDelta => targetDefenseCoefficientDelta;
        public int CoefficientModifierDurationTurns => coefficientModifierDurationTurns;
        public float LevelAttackCoefficientPerLevel => levelAttackCoefficientPerLevel;
        public int MaxLevel => maxLevel;

        public float GetOrderSpecificAttackCoefficientBonus(int orderIndex)
        {
            switch (orderIndex)
            {
                case 0:
                    return firstOrderAttackCoefficientBonus;
                case 1:
                    return secondOrderAttackCoefficientBonus;
                case 2:
                    return thirdOrderAttackCoefficientBonus;
                default:
                    return 0f;
            }
        }

        public bool IsValidForOrder(int orderIndex)
        {
            switch (orderAffinity)
            {
                case OrderAffinity.FirstOnly:
                    return orderIndex == 0;
                case OrderAffinity.SecondOnly:
                    return orderIndex == 1;
                case OrderAffinity.ThirdOnly:
                    return orderIndex == 2;
                default:
                    return true;
            }
        }

        public float GetOrderPreferenceWeight(int orderIndex)
        {
            switch (orderAffinity)
            {
                case OrderAffinity.PreferFirst:
                    return orderIndex == 0 ? 1.7f : 1f;
                case OrderAffinity.PreferSecond:
                    return orderIndex == 1 ? 1.7f : 1f;
                case OrderAffinity.PreferThird:
                    return orderIndex == 2 ? 1.7f : 1f;
                case OrderAffinity.FirstOnly:
                    return orderIndex == 0 ? 2f : 0f;
                case OrderAffinity.SecondOnly:
                    return orderIndex == 1 ? 2f : 0f;
                case OrderAffinity.ThirdOnly:
                    return orderIndex == 2 ? 2f : 0f;
                default:
                    return 1f;
            }
        }
    }
}

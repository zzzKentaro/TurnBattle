using System;
using System.Collections.Generic;
using UnityEngine;

namespace TurnBasedBattle
{
    /// <summary>
    /// �X�̖��@�̌��ʁA����R�X�g�A�����A���o�Ȃǂ��`����f�[�^�N���X�iScriptableObject�j�B
    /// </summary>
    [CreateAssetMenu(fileName = "SpellData", menuName = "TurnBattle/Spell Data")]
    public class SpellData : ScriptableObject
    {
        [Serializable]
        public class LevelGrowthEntry
        {
            [Tooltip("���̃��x���֏オ�邽�߂ɁA�O�̃��x������K�v�Ȏg�p�񐔂ł��B��: Lv.2�̍s�Ȃ�Lv.1����Lv.2�ɏオ��񐔁B")]
            [SerializeField, Min(1)] private int requiredUsesFromPreviousLevel = 1;
            [Tooltip("���̃��x���̂Ƃ��ɉ��Z�����U���W���{�[�i�X�ł��B��: 0.10�Ȃ��b�U���W����+0.10�B")]
            [SerializeField] private float attackCoefficientBonus = 0f;

            public int RequiredUsesFromPreviousLevel => Mathf.Max(1, requiredUsesFromPreviousLevel);
            public float AttackCoefficientBonus => attackCoefficientBonus;
        }
        [Header("���ʏ��")]
        [SerializeField] private string spellId = "spell_new";
        [SerializeField] private string displayName = "New Spell";
        [SerializeField, TextArea] private string description;
        [SerializeField] private Sprite iconSprite;
        [SerializeField] private OneShotParticleCallback impactEffectPrefab;
        [SerializeField] private AudioClip attackEffectSe;

        [Header("��{�ݒ�")]
        [SerializeField] private ElementType element = ElementType.None;
        [SerializeField] private SpellCategory category = SpellCategory.Attack;
        [SerializeField] private TargetType targetType = TargetType.SingleEnemy;
        [SerializeField, Min(0)] private int mpCost = 0;

        [Header("�U�� / ��")]
        [SerializeField] private float attackCoefficient = 1.0f;
        [SerializeField] private float defenseCoefficient = 1.0f;
        [SerializeField, Min(1)] private int hitCount = 1;
        [SerializeField, Min(0)] private int flatHealAmount = 0;
        [SerializeField, Min(0)] private int stackPerHit = 1;
        [SerializeField] private bool useCurrentHpAsAttackSource = false;
        [SerializeField, Range(0f, 3f)] private float missingHpAttackCoefficientBonusAtZeroHp = 0f;
        [SerializeField] private bool allowCritical = true;
        [SerializeField, Min(0f)] private float defensePenetration = 0f;

        [Header("�s�����␳")]
        [SerializeField] private OrderAffinity orderAffinity = OrderAffinity.Any;
        [SerializeField] private float firstOrderAttackCoefficientBonus = 0f;
        [SerializeField] private float secondOrderAttackCoefficientBonus = 0f;
        [SerializeField] private float thirdOrderAttackCoefficientBonus = 0f;
        [SerializeField] private float nextSpellAttackCoefficientBonus = 0f;

        [Header("�\�͒l�o�t / �f�o�t")]
        [SerializeField] private int selfAttackStatDelta = 0;
        [SerializeField] private int selfDefenseStatDelta = 0;
        [SerializeField] private int targetAttackStatDelta = 0;
        [SerializeField] private int targetDefenseStatDelta = 0;
        [SerializeField, Min(0)] private int statModifierDurationTurns = 0;

        [Header("�W���o�t / �f�o�t")]
        [SerializeField] private float selfAttackCoefficientDelta = 0f;
        [SerializeField] private float selfDefenseCoefficientDelta = 0f;
        [SerializeField] private float targetAttackCoefficientDelta = 0f;
        [SerializeField] private float targetDefenseCoefficientDelta = 0f;
        [SerializeField, Min(0)] private int coefficientModifierDurationTurns = 0;

        [Header("���x������")]
        [SerializeField, Range(0f, 1f)] private float levelAttackCoefficientPerLevel = 0.05f;
        [SerializeField] private int maxLevel = 6;
        [Tooltip("Lv.2�ȍ~�̌ʐ����ݒ�ł��B�v�f0��Lv.2�A�v�f1��Lv.3�ɑΉ����܂��B���ݒ�̃��x���͏]���̈ꗥ�ݒ���g���܂��B")]
        [SerializeField] private List<LevelGrowthEntry> levelGrowthEntries = new List<LevelGrowthEntry>();

        [Header("�g�p�񐔂ŋ����Ȃ閂�@")]
        [Tooltip("���̖��@�̑��g�p��1��ɂ����Z�����U���W���ł��B��: 0.05�Ȃ�A10��g�p�ς݂�+0.5����܂��B")]
        [SerializeField, Min(0f)] private float useCountAttackCoefficientBonusPerUse = 0f;
        [Tooltip("ON�ɂ���ƁA�g�p�񐔂ɂ��U���W���{�[�i�X�ɏ����ݒ肵�܂��B")]
        [SerializeField] private bool capUseCountAttackCoefficientBonus = false;
        [Tooltip("�g�p�񐔂ɂ��U���W���{�[�i�X�̏���ł��BcapUseCountAttackCoefficientBonus��ON�̂Ƃ������g���܂��B")]
        [SerializeField, Min(0f)] private float maxUseCountAttackCoefficientBonus = 0f;

        [Header("�g�p���̉i������")]
        [Tooltip("���̖��@�̔����ɐ������邽�сA�����̍U���͂ɉi�����Z�����l�ł��B")]
        [SerializeField, Min(0)] private int permanentSelfAttackDeltaOnUse = 0;
        [Tooltip("���̖��@�̔����ɐ������邽�сA�����̖h��͂ɉi�����Z�����l�ł��B")]
        [SerializeField, Min(0)] private int permanentSelfDefenseDeltaOnUse = 0;
        [Tooltip("���̖��@�̔����ɐ������邽�сA�����̍ő�HP�ɉi�����Z�����l�ł��B")]
        [SerializeField, Min(0)] private int permanentSelfMaxHpDeltaOnUse = 0;
        [Tooltip("���̖��@�̔����ɐ������邽�сA�����̍ő�MP�ɉi�����Z�����l�ł��B")]
        [SerializeField, Min(0)] private int permanentSelfMaxMpDeltaOnUse = 0;
        [Tooltip("�ő�HP���������Ƃ��A����HP�������ʂ����񕜂��܂��B")]
        [SerializeField] private bool restoreGainedMaxHpOnUse = true;
        [Tooltip("�ő�MP���������Ƃ��A����MP�������ʂ����񕜂��܂��B")]
        [SerializeField] private bool restoreGainedMaxMpOnUse = true;

        public string SpellId => spellId;
        public string DisplayName => displayName;
        public string Description => description;
        public Sprite IconSprite => iconSprite;
        public OneShotParticleCallback ImpactEffectPrefab => impactEffectPrefab;
        public AudioClip AttackEffectSe => attackEffectSe;
        public ElementType Element => element;
        public SpellCategory Category => category;
        public TargetType TargetType => targetType;
        public int MpCost => mpCost;
        public float AttackCoefficient => attackCoefficient;
        public float DefenseCoefficient => defenseCoefficient;
        public int HitCount => hitCount;
        public int FlatHealAmount => flatHealAmount;
        public int StackPerHit => stackPerHit;
        public bool UseCurrentHpAsAttackSource => useCurrentHpAsAttackSource;
        public float MissingHpAttackCoefficientBonusAtZeroHp => missingHpAttackCoefficientBonusAtZeroHp;
        public bool AllowCritical => allowCritical;
        public float DefensePenetration => defensePenetration;
        public OrderAffinity OrderAffinity => orderAffinity;
        public float NextSpellAttackCoefficientBonus => nextSpellAttackCoefficientBonus;
        public int SelfAttackStatDelta => selfAttackStatDelta;
        public int SelfDefenseStatDelta => selfDefenseStatDelta;
        public int TargetAttackStatDelta => targetAttackStatDelta;
        public int TargetDefenseStatDelta => targetDefenseStatDelta;
        public int StatModifierDurationTurns => statModifierDurationTurns;
        public float SelfAttackCoefficientDelta => selfAttackCoefficientDelta;
        public float SelfDefenseCoefficientDelta => selfDefenseCoefficientDelta;
        public float TargetAttackCoefficientDelta => targetAttackCoefficientDelta;
        public float TargetDefenseCoefficientDelta => targetDefenseCoefficientDelta;
        public int CoefficientModifierDurationTurns => coefficientModifierDurationTurns;
        public float LevelAttackCoefficientPerLevel => levelAttackCoefficientPerLevel;
        public int MaxLevel => Mathf.Max(1, maxLevel);
        public IReadOnlyList<LevelGrowthEntry> LevelGrowthEntries => levelGrowthEntries;
        public float UseCountAttackCoefficientBonusPerUse => useCountAttackCoefficientBonusPerUse;
        public bool CapUseCountAttackCoefficientBonus => capUseCountAttackCoefficientBonus;
        public float MaxUseCountAttackCoefficientBonus => maxUseCountAttackCoefficientBonus;
        public int PermanentSelfAttackDeltaOnUse => permanentSelfAttackDeltaOnUse;
        public int PermanentSelfDefenseDeltaOnUse => permanentSelfDefenseDeltaOnUse;
        public int PermanentSelfMaxHpDeltaOnUse => permanentSelfMaxHpDeltaOnUse;
        public int PermanentSelfMaxMpDeltaOnUse => permanentSelfMaxMpDeltaOnUse;
        public bool RestoreGainedMaxHpOnUse => restoreGainedMaxHpOnUse;
        public bool RestoreGainedMaxMpOnUse => restoreGainedMaxMpOnUse;

        public bool HasUseCountScaling => useCountAttackCoefficientBonusPerUse > 0f;

        public bool HasPermanentSelfGrowth =>
            permanentSelfAttackDeltaOnUse > 0 ||
            permanentSelfDefenseDeltaOnUse > 0 ||
            permanentSelfMaxHpDeltaOnUse > 0 ||
            permanentSelfMaxMpDeltaOnUse > 0;

        public float GetUseCountAttackCoefficientBonus(int totalUseCount)
        {
            float bonus = Mathf.Max(0, totalUseCount) * useCountAttackCoefficientBonusPerUse;
            if (capUseCountAttackCoefficientBonus)
            {
                bonus = Mathf.Min(bonus, maxUseCountAttackCoefficientBonus);
            }

            return Mathf.Max(0f, bonus);
        }


        public int GetRequiredUsesForNextLevel(int currentLevel)
        {
            int normalizedLevel = Mathf.Max(1, currentLevel);
            if (normalizedLevel >= MaxLevel)
            {
                return int.MaxValue;
            }

            LevelGrowthEntry entry = GetLevelGrowthEntry(normalizedLevel + 1);
            if (entry != null)
            {
                return entry.RequiredUsesFromPreviousLevel;
            }

            return GetDefaultRequiredUsesForNextLevel(normalizedLevel);
        }

        public float GetLevelAttackCoefficientBonus(int level)
        {
            int normalizedLevel = Mathf.Clamp(level, 1, MaxLevel);
            LevelGrowthEntry entry = GetLevelGrowthEntry(normalizedLevel);
            if (entry != null)
            {
                return entry.AttackCoefficientBonus;
            }

            return Mathf.Max(0, normalizedLevel - 1) * levelAttackCoefficientPerLevel;
        }

        private LevelGrowthEntry GetLevelGrowthEntry(int level)
        {
            int index = level - 2;
            if (levelGrowthEntries == null || index < 0 || index >= levelGrowthEntries.Count)
            {
                return null;
            }

            return levelGrowthEntries[index];
        }

        private int GetDefaultRequiredUsesForNextLevel(int currentLevel)
        {
            switch (currentLevel)
            {
                case 1:
                case 2:
                case 3:
                case 4:
                    return 1;
                case 5:
                    return 20;
                default:
                    return int.MaxValue;
            }
        }
        public float GetOrderSpecificAttackCoefficientBonus(int orderIndex)
        {
            switch (orderIndex)
            {
                case 0:
                    return firstOrderAttackCoefficientBonus;
                case 1:
                    return secondOrderAttackCoefficientBonus;
                case 2:
                    return thirdOrderAttackCoefficientBonus;
                default:
                    return 0f;
            }
        }

        public bool IsValidForOrder(int orderIndex)
        {
            switch (orderAffinity)
            {
                case OrderAffinity.FirstOnly:
                    return orderIndex == 0;
                case OrderAffinity.SecondOnly:
                    return orderIndex == 1;
                case OrderAffinity.ThirdOnly:
                    return orderIndex == 2;
                default:
                    return true;
            }
        }

        public float GetOrderPreferenceWeight(int orderIndex)
        {
            switch (orderAffinity)
            {
                case OrderAffinity.PreferFirst:
                    return orderIndex == 0 ? 1.7f : 1f;
                case OrderAffinity.PreferSecond:
                    return orderIndex == 1 ? 1.7f : 1f;
                case OrderAffinity.PreferThird:
                    return orderIndex == 2 ? 1.7f : 1f;
                case OrderAffinity.FirstOnly:
                    return orderIndex == 0 ? 2f : 0f;
                case OrderAffinity.SecondOnly:
                    return orderIndex == 1 ? 2f : 0f;
                case OrderAffinity.ThirdOnly:
                    return orderIndex == 2 ? 2f : 0f;
                default:
                    return 1f;
            }
        }
    }
}

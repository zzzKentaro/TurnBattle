using System;
using System.Collections.Generic;
using UnityEngine;

namespace TurnBasedBattle
{
    [Serializable]
    public class TimedStatModifier
    {
        public StatType statType;
        public int delta;
        public int remainingTurns;
    }

    [Serializable]
    public class TimedCoefficientModifier
    {
        public CoefficientModifierType modifierType;
        public float delta;
        public int remainingTurns;
    }

    public class BattleUnit : MonoBehaviour
    {
        [Header("Identity")]
        [SerializeField] private string unitName = "Unit";
        [SerializeField] private bool isPlayer = false;

        [Header("Base stats")]
        [SerializeField] private UnitStats baseStats = new UnitStats();

        [Header("Presentation")]
        [SerializeField] private DamageTargetAnchor damageTargetAnchor;

        [Header("Runtime")]
        [SerializeField] private int currentHP;
        [SerializeField] private int currentMP;
        [SerializeField] private ElementStackController elementStacks = new ElementStackController();
        [SerializeField] private MagicMemoryBook memoryBook = new MagicMemoryBook();
        [SerializeField] private List<SpellData> enemySpellPool = new List<SpellData>();
        [SerializeField] private List<TimedStatModifier> activeStatModifiers = new List<TimedStatModifier>();
        [SerializeField] private List<TimedCoefficientModifier> activeCoefficientModifiers = new List<TimedCoefficientModifier>();

        public IReadOnlyList<TimedStatModifier> ActiveStatModifiers => activeStatModifiers;
        public IReadOnlyList<TimedCoefficientModifier> ActiveCoefficientModifiers => activeCoefficientModifiers;

        public string UnitName => unitName;
        public bool IsPlayer => isPlayer;
        public int CurrentHP => currentHP;
        public int CurrentMP => currentMP;
        public int MaxHP => baseStats.maxHP;
        public int MaxMP => baseStats.maxMP;
        public bool IsDead => currentHP <= 0;
        public DamageTargetAnchor DamageTargetAnchor => damageTargetAnchor;
        public ElementStackController ElementStacks => elementStacks;
        public MagicMemoryBook MemoryBook => memoryBook;
        public IReadOnlyList<SpellData> EnemySpellPool => enemySpellPool;

        public void InitializeForBattle()
        {
            currentHP = baseStats.maxHP;
            currentMP = baseStats.maxMP;
            elementStacks.EnsureInitialized();
            elementStacks.ClearAll();
            activeStatModifiers.Clear();
            activeCoefficientModifiers.Clear();
        }

        public int GetCurrentAttack()
        {
            return Mathf.Max(0, baseStats.attack + GetStatModifierSum(StatType.Attack));
        }

        public int GetCurrentDefense()
        {
            return Mathf.Max(0, baseStats.defense + GetStatModifierSum(StatType.Defense));
        }

        public int GetElementStacks(ElementType elementType)
        {
            return elementStacks.GetStacks(elementType);
        }

        public float GetAttackCoefficientModifierTotal()
        {
            return GetCoefficientModifierSum(CoefficientModifierType.AttackCoefficientAdd);
        }

        public float GetDefenseCoefficientModifierTotal()
        {
            return GetCoefficientModifierSum(CoefficientModifierType.DefenseCoefficientAdd);
        }

        public bool SpendMP(int amount)
        {
            if (amount < 0)
            {
                amount = 0;
            }

            if (currentMP < amount)
            {
                return false;
            }

            currentMP -= amount;
            return true;
        }

        public void RestoreMP(int amount)
        {
            currentMP = Mathf.Clamp(currentMP + Mathf.Max(0, amount), 0, baseStats.maxMP);
        }

        public void TakeDamage(int amount)
        {
            currentHP = Mathf.Clamp(currentHP - Mathf.Max(0, amount), 0, baseStats.maxHP);
        }

        public void Heal(int amount)
        {
            currentHP = Mathf.Clamp(currentHP + Mathf.Max(0, amount), 0, baseStats.maxHP);
        }

        public void ApplyStatModifier(StatType statType, int delta, int durationTurns)
        {
            if (delta == 0 || durationTurns <= 0)
            {
                return;
            }

            activeStatModifiers.Add(new TimedStatModifier
            {
                statType = statType,
                delta = delta,
                remainingTurns = durationTurns,
            });
        }

        public void ApplyCoefficientModifier(CoefficientModifierType modifierType, float delta, int durationTurns)
        {
            if (Mathf.Approximately(delta, 0f) || durationTurns <= 0)
            {
                return;
            }

            activeCoefficientModifiers.Add(new TimedCoefficientModifier
            {
                modifierType = modifierType,
                delta = delta,
                remainingTurns = durationTurns,
            });
        }

        public void AdvanceOwnTurnEnd()
        {
            elementStacks.AdvanceTurn();
            TickStatModifiers();
            TickCoefficientModifiers();
        }

        private int GetStatModifierSum(StatType statType)
        {
            int sum = 0;
            for (int i = 0; i < activeStatModifiers.Count; i++)
            {
                if (activeStatModifiers[i].statType == statType)
                {
                    sum += activeStatModifiers[i].delta;
                }
            }
            return sum;
        }

        private float GetCoefficientModifierSum(CoefficientModifierType modifierType)
        {
            float sum = 0f;
            for (int i = 0; i < activeCoefficientModifiers.Count; i++)
            {
                if (activeCoefficientModifiers[i].modifierType == modifierType)
                {
                    sum += activeCoefficientModifiers[i].delta;
                }
            }
            return sum;
        }

        private void TickStatModifiers()
        {
            for (int i = activeStatModifiers.Count - 1; i >= 0; i--)
            {
                activeStatModifiers[i].remainingTurns--;
                if (activeStatModifiers[i].remainingTurns <= 0)
                {
                    activeStatModifiers.RemoveAt(i);
                }
            }
        }

        private void TickCoefficientModifiers()
        {
            for (int i = activeCoefficientModifiers.Count - 1; i >= 0; i--)
            {
                activeCoefficientModifiers[i].remainingTurns--;
                if (activeCoefficientModifiers[i].remainingTurns <= 0)
                {
                    activeCoefficientModifiers.RemoveAt(i);
                }
            }
        }
    }
}

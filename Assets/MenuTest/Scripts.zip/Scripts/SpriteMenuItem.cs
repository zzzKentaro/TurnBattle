using UnityEngine;
using UnityEngine.Events;

public class SpriteMenuItem : MonoBehaviour
{
    [Header("Visual")]
    [SerializeField] private SpriteRenderer targetRenderer;
    [SerializeField] private GameObject selectedMarker;
    [SerializeField] private Color normalColor = Color.white;
    [SerializeField] private Color selectedColor = new Color(1f, 0.9f, 0.4f, 1f);
    [SerializeField] private Vector3 normalScale = Vector3.one;
    [SerializeField] private Vector3 selectedScale = new Vector3(1.08f, 1.08f, 1f);

    [Header("Action")]
    [SerializeField] private UnityEvent onSubmit;

    private void Reset()
    {
        if (targetRenderer == null)
            targetRenderer = GetComponentInChildren<SpriteRenderer>();
    }

    public void SetSelected(bool isSelected)
    {
        if (targetRenderer != null)
        {
            targetRenderer.color = isSelected ? selectedColor : normalColor;
        }

        transform.localScale = isSelected ? selectedScale : normalScale;

        if (selectedMarker != null)
        {
            selectedMarker.SetActive(isSelected);
        }
    }

    public void Submit()
    {
        onSubmit?.Invoke();
    }
}